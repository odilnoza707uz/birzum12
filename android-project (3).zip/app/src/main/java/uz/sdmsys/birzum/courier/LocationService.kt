package uz.sdmsys.birzum.courier

import android.Manifest
import android.annotation.SuppressLint
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.Location
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import org.json.JSONObject
import java.util.concurrent.Executors

/**
 * Fonda joylashuvni serverga yuboradi (ilova yopiq yoki ekran o'chiq bo'lsa ham).
 * Faqat kuryer tizimga kirgan paytda ishlaydi; sessiya tugasa (401) o'zi to'xtaydi.
 */
class LocationService : Service() {

    companion object {
        @Volatile
        var running = false
    }

    private lateinit var client: FusedLocationProviderClient
    private var callback: LocationCallback? = null
    private var last: Location? = null
    private var lastSent = 0L
    private val io = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())

    // Harakatsiz turganda ham har ~45 soniyada oxirgi joylashuv yuboriladi (server "jonli" deb hisoblashi uchun)
    private val heartbeat = object : Runnable {
        override fun run() {
            last?.let { send(it, true) }
            handler.postDelayed(this, 45_000L)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        client = LocationServices.getFusedLocationProviderClient(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            ServiceCompat.startForeground(this, Notif.ID_TRACK, Notif.tracking(this), ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        running = true
        startUpdates()
        handler.removeCallbacks(heartbeat)
        handler.postDelayed(heartbeat, 45_000L)
        return START_STICKY
    }

    @SuppressLint("MissingPermission")
    private fun startUpdates() {
        if (callback != null) return
        val req = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 10_000L)
            .setMinUpdateIntervalMillis(5_000L)
            .build()
        val cb = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                result.lastLocation?.let {
                    last = it
                    send(it, false)
                }
            }
        }
        callback = cb
        client.requestLocationUpdates(req, cb, Looper.getMainLooper())
    }

    private fun send(loc: Location, force: Boolean) {
        val now = SystemClock.elapsedRealtime()
        if (!force && now - lastSent < 8_000L) return
        lastSent = now
        val app = applicationContext
        io.execute {
            val body = JSONObject().put("lat", loc.latitude).put("lng", loc.longitude).put("quiet", true)
            val r = Net.call(app, "loc", body)
            if (r != null && r.code == 401) sessionEnded()
        }
    }

    private fun sessionEnded() {
        Prefs.setLoggedIn(this, false)
        handler.post {
            Notif.info(this, getString(R.string.session_ended), getString(R.string.session_ended_h))
            stopSelf()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(heartbeat)
        callback?.let { client.removeLocationUpdates(it) }
        callback = null
        running = false
        io.shutdown()
        super.onDestroy()
    }
}
