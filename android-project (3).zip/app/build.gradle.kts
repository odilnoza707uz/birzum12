plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.gms.google-services")
}

// Quyidagi uchta qiymatni GitHub Actions o'zi beradi (build.yml):
//  appId   — google-services.json ichidagi paket nomi (Firebase bilan mos bo'lishi shart)
//  baseUrl — sayt manzili
//  versionCode — har yig'ishda oshib boradi
val appIdProp = (project.findProperty("appId") as String?)?.takeIf { it.isNotBlank() } ?: "uz.sdmsys.birzum.courier"
val baseUrlProp = (project.findProperty("baseUrl") as String?)?.takeIf { it.isNotBlank() } ?: "https://birzum.asakaedu.uz/"
val vcode = (project.findProperty("versionCode") as String?)?.toIntOrNull() ?: 1

android {
    namespace = "uz.sdmsys.birzum.courier"
    compileSdk = 35

    defaultConfig {
        applicationId = appIdProp
        minSdk = 26
        targetSdk = 35
        versionCode = vcode
        versionName = "1.0.$vcode"
        buildConfigField("String", "BASE_URL", "\"$baseUrlProp\"")
    }

    signingConfigs {
        create("release") {
            val ks = System.getenv("KEYSTORE_PATH")
            if (!ks.isNullOrBlank() && file(ks).exists()) {
                storeFile = file(ks)
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS") ?: "birzum"
                keyPassword = System.getenv("KEYSTORE_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // Kalit berilmasa, sinov kaliti bilan imzolanadi (o'rnatish mumkin, lekin do'konlarga yuklab bo'lmaydi)
            signingConfig = if (!System.getenv("KEYSTORE_PATH").isNullOrBlank()) {
                signingConfigs.getByName("release")
            } else {
                signingConfigs.getByName("debug")
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        buildConfig = true
    }
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation(platform("com.google.firebase:firebase-bom:33.5.1"))
    implementation("com.google.firebase:firebase-messaging")
    implementation("com.google.android.gms:play-services-location:21.3.0")
}
