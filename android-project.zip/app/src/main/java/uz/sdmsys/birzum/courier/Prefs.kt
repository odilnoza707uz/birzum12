package uz.sdmsys.birzum.courier

import android.content.Context

/** Kichik sozlamalar ombori: push tokeni, kirgan-kirmaganligi, sessiya cookie'si */
object Prefs {
    private const val FILE = "bz_courier"

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun token(c: Context): String = sp(c).getString("fcm_token", "") ?: ""
    fun setToken(c: Context, v: String) = sp(c).edit().putString("fcm_token", v).apply()

    fun tokenSent(c: Context): String = sp(c).getString("fcm_sent", "") ?: ""
    fun setTokenSent(c: Context, v: String) = sp(c).edit().putString("fcm_sent", v).apply()

    fun loggedIn(c: Context): Boolean = sp(c).getBoolean("logged_in", false)
    fun setLoggedIn(c: Context, v: Boolean) = sp(c).edit().putBoolean("logged_in", v).apply()

    fun cookie(c: Context): String = sp(c).getString("cookie", "") ?: ""
    fun setCookie(c: Context, v: String) = sp(c).edit().putString("cookie", v).apply()

    fun oemDone(c: Context): Boolean = sp(c).getBoolean("oem_done", false)
    fun setOemDone(c: Context, v: Boolean) = sp(c).edit().putBoolean("oem_done", v).apply()
}
