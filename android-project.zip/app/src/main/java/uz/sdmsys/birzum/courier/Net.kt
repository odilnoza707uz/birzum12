package uz.sdmsys.birzum.courier

import android.content.Context
import android.webkit.CookieManager
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Serverga fondan (WebView ochiq bo'lmasa ham) so'rov yuborish.
 * Sessiya cookie'si WebView'dan olinadi; CSRF token esa "state" so'rovidan.
 * Hamma so'rovlar "quiet" bilan ketadi: ular 4 soatlik "bo'sh turish" hisobini yangilamaydi.
 */
object Net {
    private val lock = Any()
    private var csrf: String? = null

    class Resp(val code: Int, val json: JSONObject?)

    private fun cookie(ctx: Context): String {
        val live = try {
            CookieManager.getInstance().getCookie(BuildConfig.BASE_URL)
        } catch (e: Throwable) {
            null
        }
        if (!live.isNullOrEmpty()) {
            Prefs.setCookie(ctx, live)
            return live
        }
        return Prefs.cookie(ctx)
    }

    private fun request(ctx: Context, action: String, body: JSONObject, withCsrf: Boolean): Resp {
        val conn = URL(BuildConfig.BASE_URL + "c/api.php?a=" + action).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 10000
            conn.readTimeout = 15000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("Accept", "application/json")
            conn.setRequestProperty("Cookie", cookie(ctx))
            if (withCsrf) conn.setRequestProperty("X-CSRF-Token", csrf ?: "")
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..399) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            val json = try {
                JSONObject(text)
            } catch (e: Exception) {
                null
            }
            return Resp(code, json)
        } finally {
            conn.disconnect()
        }
    }

    private fun refreshCsrf(ctx: Context) {
        val st = request(ctx, "state", JSONObject().put("quiet", true), false)
        csrf = st.json?.optString("csrf")
    }

    /** Muvaffaqiyatsiz bo'lsa null. code == 401 bo'lsa sessiya tugagan (qayta kirish kerak). */
    fun call(ctx: Context, action: String, body: JSONObject = JSONObject()): Resp? {
        return try {
            synchronized(lock) {
                if (csrf.isNullOrEmpty()) refreshCsrf(ctx)
                var r = request(ctx, action, body, true)
                if (r.code == 419 || r.json?.optBoolean("reload") == true) {
                    refreshCsrf(ctx)
                    r = request(ctx, action, body, true)
                }
                r
            }
        } catch (e: Exception) {
            null
        }
    }
}
